# wex v5.0.0-beta.2

A single entrypoint to execute custom bash scripts, and run Docker application on several environments. See description for more info.

Join our community, support us, and find work at https://wexample.com 🤝❤️👨‍💻

## License

This project is licensed under the MIT License. For more information, please see the [MIT License on the official Open Source Initiative (OSI) website](https://opensource.org/licenses/MIT).
