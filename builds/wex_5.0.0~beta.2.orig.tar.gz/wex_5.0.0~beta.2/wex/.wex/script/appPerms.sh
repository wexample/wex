#!/usr/bin/env bash

_wexLog "Setting app custom files permissions"
