#!/usr/bin/env bash

echo "cd /opt/wex-dev"
